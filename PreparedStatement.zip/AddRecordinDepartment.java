package edu.com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;
public class AddRecordinDepartment {
	
		public static void main(String[] args) throws ClassNotFoundException, SQLException {
			// TODO Auto-generated method stub
			String driver="com.mysql.cj.jdbc.Driver";
			String url="jdbc:mysql://localhost:3306/sakila";
			String un="root";
			String pass="root";
			
			int did;
			String dname;
			
			
			Class.forName(driver);
			
			Connection conn=DriverManager.getConnection(url,un,pass);
			Statement stmt = conn.createStatement();
			
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter department id");
			did=sc.nextInt();
			
			String sql="select * from department where did="+did;
			ResultSet rs=stmt.executeQuery(sql);
			
			if(rs.next()) {
				System.out.println(did+" already exist");
			}
			else {
				
				System.out.println("Enter Id");
				did=sc.nextInt();
				System.out.println("Enter Name");
				dname=sc.next();
				
				
				String inssql="Insert into department(did,dname) values("+did+",'"+dname+"')";
				int i =stmt.executeUpdate(inssql);
				
				if(i>0) {
					System.out.println("Record added succesfully");
				}
			}
			
		}

	}

