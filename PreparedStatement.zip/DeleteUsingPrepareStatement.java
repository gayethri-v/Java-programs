package edu.com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class DeleteUsingPrepareStatement {
	 public static void main(String[] args) throws ClassNotFoundException, SQLException {

	        int eid;
	        PreparedStatement pst;

	        Scanner sc = new Scanner(System.in);

	        String driver = "com.mysql.cj.jdbc.Driver";
	        String url = "jdbc:mysql://localhost:3306/sakila";
	        String un = "root";
	        String pass = "root";

	     
	        Class.forName(driver);

	        Connection conn = DriverManager.getConnection(url, un, pass);

	        System.out.println("Enter employee id to delete:");
	        eid = sc.nextInt();

	        String sql = "select * from employees where eid = ?";
	        pst = conn.prepareStatement(sql);
	        pst.setInt(1, eid);

	        ResultSet rs = pst.executeQuery();

	        if (rs.next()) {
	  
	            String delsql = "delete from employees where eid = ?";
	            pst = conn.prepareStatement(delsql);
	            pst.setInt(1, eid);

	            int i = pst.executeUpdate();

	            if (i > 0) {
	                System.out.println("Record deleted successfully.");
	            }
	        } else {
	            System.out.println(eid + " does not exist.");
	        }

	  
	    }
	}


