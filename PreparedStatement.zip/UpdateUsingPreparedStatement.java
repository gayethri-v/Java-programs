package edu.com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;
public class UpdateUsingPreparedStatement {
	 public static void main(String[] args) throws ClassNotFoundException, SQLException {

	        int eid, did;
	        String ename;
	        float esalary;
	        PreparedStatement pst;

	        Scanner sc = new Scanner(System.in);

	        String driver = "com.mysql.cj.jdbc.Driver";
	        String url = "jdbc:mysql://localhost:3306/sakila";
	        String un = "root";
	        String pass = "root";

	        Class.forName(driver);

	        Connection conn = DriverManager.getConnection(url, un, pass);

	        System.out.println("Enter employee id to update:");
	        eid = sc.nextInt();

	        String sql = "select * from employees where eid = ?";
	        pst = conn.prepareStatement(sql);
	        pst.setInt(1, eid);

	        ResultSet rs = pst.executeQuery();

	        if (rs.next()) {
	            
	            System.out.println("Enter new name:");
	            ename = sc.next();

	            System.out.println("Enter new salary:");
	            esalary = sc.nextFloat();

	            System.out.println("Enter new department id (10, 20, 30):");
	            did = sc.nextInt();

	           
	            String updatesql = "update employees set ename = ?, esalary = ?, did = ? WHERE eid = ?";
	            pst = conn.prepareStatement(updatesql);
	            pst.setString(1, ename);
	            pst.setFloat(2, esalary);
	            pst.setInt(3, did);
	            pst.setInt(4, eid);

	            int i = pst.executeUpdate();

	            if (i > 0) {
	                System.out.println("Record updated successfully.");
	            }
	        } else {
	            System.out.println(eid + " does not exist.");
	        }

	        
	    }
	}


