package edu.com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.ResultSet;
public class DatabaseConnectFetchRecord {
	public static void  main(String[] args) throws ClassNotFoundException,SQLException{
		
		
		
		
		
		
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/sakila";
		String un="root";
		String pass="root";
		
		Class.forName(driver);
		
		Connection conn=DriverManager.getConnection(url, un, pass);
//		System.out.println(conn);
		//String s="select * from employees";
		String s="select * from department";
	
		Statement stmt=conn.createStatement();
		ResultSet rs =stmt.executeQuery(s);
		System.out.println("did\tdname");
		while(rs.next()){
			int did=rs.getInt("did");
			String dname = rs.getString("dname");
			System.out.println(did+"\t"+dname+"\t");
		}
		
//		System.out.println("eid\tename\tesalary\tdid");
//		while(rs.next()) {
//			int eid=rs.getInt("eid");
//			String ename=rs.getString("ename");
//			float esalary=rs.getFloat("esalary");
//			int did=rs.getInt("did");
//			System.out.println(eid+"\t"+ename+"\t"+esalary+"\t"+did+"\t");
//		}
		
		
		
	}

}
