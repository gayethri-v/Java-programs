package edu.com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class UpdateSwitchInDepartment {

		public static void main(String[] args) throws ClassNotFoundException, SQLException {
			// TODO Auto-generated method stub
			String driver="com.mysql.cj.jdbc.Driver";
			String url="jdbc:mysql://localhost:3306/sakila";
			String un="root";
			String pass="root";
			int r;
			
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter id to update Record");
			int did = sc.nextInt();
			
			Class.forName(driver);
			
			Connection conn = DriverManager.getConnection(url, un, pass);
			
			
			Statement stmt = conn.createStatement();
			
			
			
			String sql = "select * from department where did="+did;
			
			
			ResultSet rs = stmt.executeQuery(sql);
			
			if(rs.next()) {  //if record exists, then go for delete
				
				//MENU
				System.out.println("Enter your choice");
				System.out.println("1.to update name");
				System.out.println("2.to Delete name");
				//System.out.println("3.to Add name");
				
				
				int ch = sc.nextInt();
				switch(ch) {
				case 1:System.out.println("Enter name to change");		
						String name = sc.next();
						String upsql = "update department set dname='"+name+"' where did="+did;
						 r = stmt.executeUpdate(upsql);
			
						if(r>0) {
							System.out.println("name with id="+did +" is Updated");
							}
						break;
				case 2: System.out.println("Enter name to delete");
				       // String name1 = sc.next();
				        String namede = "delete from department where did="+did;
				        r = stmt.executeUpdate(namede);
				        if(r>0) {
							System.out.println("Name with did="+did +" is deleted");
							}
						break;
				case 3: System.out.println("Enter name to Add");
//			        String dname1 = sc.next();
//			        String nameadd = "Insert into department(did,dname) values("+did+",'"+dname1+"')"+did;
//			        r = stmt.executeUpdate(nameadd);
//			        if(r>0) {
//						System.out.println("Name with did="+did +" is Added");
//						}
//					break;		
			}//switch
			}//if(rs.next())
				
				else {
				System.out.println(did+" not exists");
			}sc.close();
			
			
		}

	}






