package edu.com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class UpdateRecortById {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/sakila";
		String un="root";
		String pass="root";
		
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id to update record");
		int id=sc.nextInt();
		
		System.out.println("Enter new name:");
        String name = sc.next();
		//Step 1:load the driver
		
		Class.forName(driver);
		//Step 2 make the connection
		
		Connection conn = DriverManager.getConnection(url, un, pass);
		
		Statement stmt = conn.createStatement();
		
		String sql = "select * from employees where eid="+id;
		
		ResultSet rs = stmt.executeQuery(sql);
		
		 if (rs.next()) {
	            String upsql = "update employees set ename='" + name + "' where eid=" + id;
	            int r = stmt.executeUpdate(upsql);
	            
	            if (r > 0) {
	                System.out.println("Name is changed successfully.");
	            }
	        } else {
	            System.out.println(id + " does not exist.");
	        }
			
		
		sc.close();
		
	}

}

