package edu.com;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class AddRecord {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/sakila";
		String un="root";
		String pass="root";
		
		int eid,did;
		String ename;
		float esalary;
		
		Class.forName(driver);
		
		Connection conn=DriverManager.getConnection(url,un,pass);
		Statement stmt = conn.createStatement();
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Employee id");
		eid=sc.nextInt();
		
		String sql="select * from employees where eid="+eid;
		ResultSet rs=stmt.executeQuery(sql);
		
		if(rs.next()) {
			System.out.println(eid+" already exist");
		}
		else {
			
			System.out.println("Enter name");
			ename=sc.next();
			System.out.println("Enter salary");
			esalary=sc.nextFloat();
			System.out.println("Enter did (10,20,30)");
			did=sc.nextInt();
			
			String inssql="Insert into employees(eid,ename,esalary,did) values("+eid+",'"+ename+"',"+esalary+","+did+")";
			int i =stmt.executeUpdate(inssql);
			
			if(i>0) {
				System.out.println("Record added succesfully");
			}
		}
		
	}

}
