package edu.com;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class DeleteRecordById {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		String driver="com.mysql.cj.jdbc.Driver";
		String url="jdbc:mysql://localhost:3306/sakila";
		String un="root";
		String pass="root";
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter id to delete record");
		int id=sc.nextInt();
		
		//Step 1:load the driver
		
		Class.forName(driver);
		//Step 2 make the connection
		
		Connection conn = DriverManager.getConnection(url, un, pass);
		
		Statement stmt = conn.createStatement();
		
		String sql = "select * from employees where eid="+id;
		
		ResultSet rs = stmt.executeQuery(sql);
		
		if(rs.next()) {
			String delsql="delete from employees where eid="+id;
			int r=stmt.executeUpdate(delsql);
			
			if(r>0) {
				System.out.println("Record with id="+id +" is deleted");
			}
				
			}else {
				System.out.println("Record not exist");
			}
			
			
		
		sc.close();
		
	}

}
