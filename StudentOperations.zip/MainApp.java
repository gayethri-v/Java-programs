package com.edu;

import java.sql.SQLException;
import java.util.Scanner;

public class MainApp {

	public static void main(String[] args) throws SQLException, ClassNotFoundException {
		while (true) {
		Scanner sc=new Scanner(System.in);
		System.out.println("*******Student Management System*******");
		System.out.println("1.Display Student");
		System.out.println("2.Add Student");
		System.out.println("3.Delete Student by id");
		System.out.println("4.Update Student by id");
		System.out.println("5.Get Student by id");
		
		System.out.println("Enter your choice");
		int ch=sc.nextInt();
		
		switch(ch) {
		case 1:StudentOperations.displayStudent();
		       break;
		       
		case 2:StudentOperations.addStudent();
		       break;
		       
		case 3:StudentOperations.deleteStudent();
		       break;
		   
		case 4:StudentOperations.updateStudent();
	           break;
	       
		case 5:StudentOperations.getStudent();
	       break;   
	       
	     default : System.out.println("Invalid input");  
		}
		
		System.out.println("Do you want to continue?, press y to continue and any other key to exit ");
		
		char ch1=sc.next().charAt(0);
		if(ch1!='y') {
			System.out.println("Program Exit");
			break;
			
	}
		System.out.println("Program is terminated");
		

	}

}


}
