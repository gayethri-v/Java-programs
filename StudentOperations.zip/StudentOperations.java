package com.edu;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class StudentOperations {

	private static Connection conn;
	private static PreparedStatement pst;
	private static String sql;
	private static int sid;
	private static String sname;
	private static int sage;
	private static String semailid;
	private static int sphone;

		public static void displayStudent() throws ClassNotFoundException, SQLException {
			
			conn = DatabaseConnection.getConnection();
			sql = "select * from student";
			
			
		    pst = conn.prepareStatement(sql);
			
			
			ResultSet rs = pst.executeQuery();
			
			System.out.println("sid\tsname\tsage\tsemailid\tsphone");
			while(rs.next()) {
				sid = rs.getInt("sid");
				sname =  rs.getString("sname");
				sage = rs.getInt("sage");
				semailid = rs.getString("semailid");
				sphone = rs.getInt("sphone");
				
				System.out.println(sid+"\t"+sname+"\t"+sage+"\t"+semailid+"\t"+sphone);
			}
			
	}

		public static void addStudent() throws ClassNotFoundException, SQLException {
			Scanner sc = new Scanner(System.in);
			
			System.out.println("Enter Student id");
			sid = sc.nextInt();
						
			String sql = "select * from student where sid=?";
			pst = conn.prepareStatement(sql);
			pst.setInt(1, sid);
			ResultSet rs = pst.executeQuery();
			
			if(rs.next()) {
				System.out.println(sid+" already exists ");
				return;
			}
			else 
			{
				System.out.println("Enter name");
				sname = sc.next();
				System.out.println("Enter age");
				sage = sc.nextInt();
				System.out.println("Enter Emailid");
				semailid=sc.next();
				System.out.println("Enter Phone Number");
				sphone = sc.nextInt();
			
				conn = DatabaseConnection.getConnection();
				
				String inssql ="insert into student(sid,sname,sage,semailid,sphone) values(?,?,?,?,?)";  
			    pst = conn.prepareStatement(inssql);
			    pst.setInt(1, sid);
			    pst.setString(2, sname);
			    pst.setInt(3, sage);
	            pst.setString(4,semailid);
	            pst.setInt(5,sphone);
			    
			int i = pst.executeUpdate();
			
			    
			    if(i>0) {
			    	System.out.println("Record added successfully");
			    }
			}
			
			
		}

		public static void deleteStudent() throws SQLException, ClassNotFoundException {
			
			conn = DatabaseConnection.getConnection();
						
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter id to delete record");
			
			int id = sc.nextInt();
			
					String sql = "select * from student where sid=?";
					
					pst = conn.prepareStatement(sql);
					pst.setInt(1, id);
					ResultSet rs = pst.executeQuery();
					
					if(rs.next()) {  
						String delsql ="delete from student where sid=?";	
								pst=conn.prepareStatement(delsql);
							pst.setInt(1, id);
					int r = pst.executeUpdate();
					
					if(r>0) {
						System.out.println("Record with id="+id +" is deleted");
					   }
					}else {
						System.out.println("Record not exists");
					}
					
					
			
		}

		public static void updateStudent() throws ClassNotFoundException, SQLException {
		    conn = DatabaseConnection.getConnection();    
		    Scanner sc = new Scanner(System.in);

		    System.out.println("Enter id to update Record");
		    int id = sc.nextInt();

		    // Check if the student exists
		    String sql = "select * from student where sid=?";
		    pst = conn.prepareStatement(sql);
		    pst.setInt(1, id);

		    ResultSet rs = pst.executeQuery();

		    if (rs.next()) {
		        // If record exists, prompt the user to choose which field to update
		        System.out.println("Which field do you want to update?");
		        System.out.println("1. Name");
		        System.out.println("2. Age");
		        System.out.println("3. Email ID");
		        System.out.println("Enter your choice");
		        int choice = sc.nextInt();

		        String upsql = "";
		        switch (choice) {
		            case 1:
		                System.out.println("Enter new name:");
		                String newName = sc.next();
		                upsql = "update student set sname=? where sid=?";
		                pst = conn.prepareStatement(upsql);
		                pst.setString(1, newName);
		                pst.setInt(2, id);
		                break;
		            case 2:
		                System.out.println("Enter new age:");
		                int newAge = sc.nextInt();
		                upsql = "update student set sage=? where sid=?";
		                pst = conn.prepareStatement(upsql);
		                pst.setInt(1, newAge);
		                pst.setInt(2, id);
		                break;
		            case 3:
		                System.out.println("Enter new email ID:");
		                String newEmail = sc.next();
		                upsql = "update student set semailid=? where sid=?";
		                pst = conn.prepareStatement(upsql);
		                pst.setString(1, newEmail);
		                pst.setInt(2, id);
		                break;
		            default:
		                System.out.println("Invalid choice.");
		                return;
		        }

		        int r = pst.executeUpdate();
		        if (r > 0) {
		            System.out.println("Record with id=" + id + " is updated");
		        }
		    } else {
		        System.out.println("Record not exists");
		    }
		}


		public static void getStudent() throws ClassNotFoundException, SQLException {
			
			
			Scanner sc = new Scanner(System.in);
			conn = DatabaseConnection.getConnection();
			System.out.println("Enter student id");
			sid = sc.nextInt();
				
			
			 sql = "select * from student where sid=?";
			
			
			pst = conn.prepareStatement(sql);
			pst.setInt(1, sid);
			
			ResultSet rs = pst.executeQuery();
				
			if(rs.next()) {
				System.out.println("sid\tsname\tsage\tsemailid\tsphone");
				sid = rs.getInt("sid");
				sname =  rs.getString("sname");
				sage = rs.getInt("sage");
				semailid = rs.getString("semailid");
				sphone = rs.getInt("sphone");
				
				System.out.println(sid+"\t"+sname+"\t"+sage+"\t"+semailid+"\t"+sphone);
			}else {
				System.out.println("Student not exist");
			}
			
		}

		
	}

